# صفحات بوت القرآن

الملفات:
- terms.html = Terms of Service
- privacy.html = Privacy Policy

هذه الصفحات تحتاج إلى استضافة عامة (Public HTTPS URL) قبل وضعها في Discord Developer Portal.

روابط Discord:
Terms of Service URL -> رابط terms.html
Privacy Policy URL -> رابط privacy.html

رابط قناة YouTube:
https://youtube.com/@dartic7
